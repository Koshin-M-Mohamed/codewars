function boolToWord( bool ){
    if( bool ) return 'Yes'
    return 'No'
    }
    